class Element {
    
    let letter: Character
    let value: Int
    
    init(letter: Character) {
        self.letter = letter
        self.value = Int(letter.unicodeScalars.first?.value ?? 0)
    }
}

let surname = "вдовиченко_владислав"
let keyword = "метал"


func generateKeywordSymbols(_ keyword: String) -> [Element] {
    var elems = [Element]()
    for char in keyword {
        let elem = Element(letter: char)
        elems.append(elem)
    }
    return elems
}

let keywordArray = generateKeywordSymbols(keyword)

func createMatrixFromSurname(_ surname: String, and keyword: String) -> [[Character]] {
    let count = keyword.count
    var rowCount = 0
    while count * rowCount < surname.count {
        rowCount += 1
    }
    var characters = Array(repeating: Array(repeating: Character("-"), count: count), count: rowCount)
    let array = Array(surname)
    var index = 0
    for i in characters.indices {
        for j in characters[i].indices {
            if index < array.count {
                characters[i][j] = array[index]
                index += 1
            }
        }
    }
    return characters
}

let matrix = createMatrixFromSurname(surname, and: keyword)

func generateDictionaryFrom(matrix: [[Character]], and keywordArray: [Element]) -> [Int: [Character]] {
    var dict = [Int: [Character]]()
    for index in keywordArray.indices {
        let num = keywordArray[index].value
        var charArray = [Character]()
        for i in matrix.indices {
            let char = matrix[i][index]
            charArray.append(char)
        }
        dict.updateValue(charArray, forKey: num)
    }
    return dict
}

let dict = generateDictionaryFrom(matrix: matrix, and: keywordArray)

func getSortedArrayOfNumbers(dict: [Int: [Character]]) -> [Int] {
    return Array(dict.keys).sorted()
}

func cipher(dict: [Int: [Character]], sortedNumbers: [Int]) -> String {
    var stringToReturn = ""
    for num in sortedNumbers {
        let value = dict[num] ?? [Character]()
        for char in value {
            stringToReturn.append(char)
        }
    }
    return stringToReturn
}

let newSurname = cipher(dict: dict, sortedNumbers: getSortedArrayOfNumbers(dict: dict))
print(newSurname)

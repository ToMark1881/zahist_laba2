let surname = "вдовиченко_владислав"

func createTableFromSurname(_ name: String) -> [[Character]] {
    var characters = Array(repeating: Array(repeating: Character("-"), count: 4), count: 5)
    var index = 0
    let array = Array(name)
    for i in characters.indices {
        for j in characters[i].indices {
            if index < array.count {
                characters[i][j] = array[index]
                index += 1
            }
        }
    }
    return characters
} //маршрут вписування аналогічний до маршруту в звіті

let matrix = createTableFromSurname(surname)

func reverseMatrix(_ matrix: [[Character]]) -> [[Character]] {
    var characters = Array(repeating: Array(repeating: Character("-"), count: 5), count: 4)
    
    for i in matrix.indices {
        for j in matrix[i].indices {
            characters[j][i] = matrix[i][j]
        }
    }
    return characters
} //необхідно "переврнути" матрицю задля реалізації маршруту

func readCipheredStringFromMatrix(_ matrix: [[Character]]) -> String {
    var cipheredString = ""
    let newMatrix = reverseMatrix(matrix)
    for i in newMatrix.indices {
        for j in newMatrix[i].indices {
            let newI = i
            let newJ = (newMatrix[i].count - 1) - j
            cipheredString.append(newMatrix[newI][newJ])
        }
    }
    
    return cipheredString
} //маршрут зчитування аналогіний до маршруту в звіті

let newString = readCipheredStringFromMatrix(matrix)
print(newString)

let startMessage = "вдовиченко+влад"

let size = 4

class Index {
    let i: Int
    let j: Int
    
    init(i: Int, j: Int) {
        self.i = i
        self.j = j
    }
}

func appendLettersToStartMessage(_ str: String) -> String {
    var workingStr = str
    while workingStr.count < size*size {
        workingStr.append("_")
    }
    return workingStr
}

func createEmptyMatrix(with size: Int) -> [[Character]] {
    let characters = Array(repeating: Array(repeating: Character("-"), count: size), count: size)
    return characters
}

let emptyMatrix = createEmptyMatrix(with: size)
let workingMessage = appendLettersToStartMessage(startMessage)

func generateBasicIndexesAndWriteIntoMatrix(_ matrix: [[Character]], _ str: String) -> (matrix: [[Character]], indexes: [Index]) {
    var characters = matrix
    var indexes = [Index]()
    indexes.append(Index(i: 0, j: 0))
    indexes.append(Index(i: size - 2, j: 0))
    indexes.append(Index(i: 1, j: size - 2))
    indexes.append(Index(i: size - 1, j: size - 2))
    
    var index = 0
    let array = Array(str)
    for i in indexes {
        characters[i.j][i.i] = array[index]
        index += 1
    }
    return (characters, indexes)
}

let (matrix, indexes) = generateBasicIndexesAndWriteIntoMatrix(emptyMatrix, workingMessage)

func rotate180Horizontal(_ matrix: [[Character]], str: String, indexes: [Index], index: Int = 4) -> (matrix: [[Character]], indexes: [Index]) {
    var workingIndex = index
    var characters = matrix
    var newIndexes = [Index]()
    
    for index in indexes {
        let newIndex = Index(i: (size-1) - index.i, j: index.j)
        newIndexes.append(newIndex)
    }
    newIndexes.swapAt(0, 1)
    newIndexes.swapAt(2, 3)
    
    let array = Array(str)
    for i in newIndexes {
        characters[i.j][i.i] = array[workingIndex]
        workingIndex += 1
    }
    return (characters, newIndexes)
}

let (rotation1Matrix, rotation1Indexes) = rotate180Horizontal(matrix, str: workingMessage, indexes: indexes, index: 4)

func rotate180Vertical(_ matrix: [[Character]], str: String, indexes: [Index], index: Int) -> (matrix: [[Character]], indexes: [Index]) {
    var workingIndex = index
    var characters = matrix
    var newIndexes = [Index]()
    
    for index in indexes {
        let newIndex = Index(i: index.i, j: index.j + 1)
        newIndexes.append(newIndex)
    }
    
    let array = Array(str)
    for i in newIndexes {
        characters[i.j][i.i] = array[workingIndex]
        workingIndex += 1
    }
    return (characters, newIndexes)
}

let (rotation2Matrix, rotation2Indexes) = rotate180Vertical(rotation1Matrix, str: workingMessage, indexes: indexes, index: 8)
let (rotation3Matrix, rotation3Indexes) = rotate180Horizontal(rotation2Matrix, str: workingMessage, indexes: rotation2Indexes, index: 12)


func reverseMatrix(_ matrix: [[Character]]) -> [[Character]] {
    var characters = Array(repeating: Array(repeating: Character("-"), count: 4), count: 4)
    
    for i in matrix.indices {
        for j in matrix[i].indices {
            characters[j][i] = matrix[i][j]
        }
    }
    return characters
}

let reversedMatrix = reverseMatrix(rotation3Matrix)

func cipher(_ matrix: [[Character]]) -> String {
    var newString = ""
    
    for i in matrix.indices {
        for j in matrix[i].indices {
            newString.append(matrix[i][j])
        }
    }
    
    return newString
}

let newName = cipher(reversedMatrix)
print(newName)




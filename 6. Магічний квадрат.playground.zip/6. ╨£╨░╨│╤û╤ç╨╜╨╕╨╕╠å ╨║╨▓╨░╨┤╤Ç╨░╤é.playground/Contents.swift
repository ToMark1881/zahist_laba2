let startMessage = "вдовиченко+влад"

let magicSquare = [[16, 3, 2, 13],
                   [5, 10, 11, 8],
                   [9, 6, 7, 12],
                   [4, 15, 14, 1]]

func addLettersToSurname(_ surname: String) -> String {
    var name = surname
    
    while name.count % magicSquare.count != 0 {
        name.append(Character("-"))
    }
    
    return name
}

let workingName = addLettersToSurname(startMessage)

func generateDict(_ name: String, square: [[Int]]) -> [Int: Character] {
    var dict = [Int: Character]()
    let array = Array(name)
    for index in array.indices {
        dict.updateValue(array[index], forKey: index + 1)
    }
    return dict
}

let dict = generateDict(workingName, square: magicSquare)


func cipher(_ dict: [Int: Character]) -> String {
    var stringToReturn = ""
    for i in magicSquare.indices {
        for j in magicSquare.indices {
            let num = magicSquare[i][j]
            let char = dict[num] ?? "-"
            //print("\(num) : \(char)")
            stringToReturn.append(char)
        }
    }
    return stringToReturn
}

let name = cipher(dict)
print(name)



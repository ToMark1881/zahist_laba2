let startMessage = "вдовиченко+влад"

let size = 4
let rowKey = [3, 4, 1, 2]
let columnKey = [4, 1, 3, 2]

func appendLettersToStartMessage(_ str: String) -> String {
    var workingStr = str
    while workingStr.count < size*size {
        workingStr.append("-")
    }
    return workingStr
}

let workingMessage = appendLettersToStartMessage(startMessage)

func createMatrix(with size: Int, message: String) -> [[Character]] {
    var characters = Array(repeating: Array(repeating: Character("-"), count: size), count: size)
    var index = 0
    let array = Array(message)
    for i in characters.indices {
        for j in characters.indices {
            characters[i][j] = array[index]
            index += 1
        }
    }
    return characters
}

let matrix = createMatrix(with: size, message: workingMessage)

func moveRows(_ matrix: [[Character]]) -> [[Character]] {
    var workingMatrix = [[Character]]()
    var dict = [Int : [Character]]()
    for index in rowKey.indices {
        dict.updateValue(matrix[index], forKey: rowKey[index])
    }
    for index in 1..<dict.count+1 {
        workingMatrix.append(dict[index] ?? [Character]())
    }
    return workingMatrix
}

let rows = moveRows(matrix)

func reverseMatrix(_ matrix: [[Character]]) -> [[Character]] {
    var characters = Array(repeating: Array(repeating: Character("-"), count: 4), count: 4)
    
    for i in matrix.indices {
        for j in matrix[i].indices {
            characters[j][i] = matrix[i][j]
        }
    }
    return characters
}

let reversedMatrix = reverseMatrix(rows)

func moveColumns(_ matrix: [[Character]]) -> [[Character]] {
    var workingMatrix = [[Character]]()
    var dict = [Int : [Character]]()
    for index in columnKey.indices {
        dict.updateValue(matrix[index], forKey: columnKey[index])
    }
    for index in 1..<dict.count+1 {
        workingMatrix.append(dict[index] ?? [Character]())
    }
    return workingMatrix
}

let column = moveColumns(reversedMatrix)

func cipher(_ matrix: [[Character]]) -> String {
    var stringToReturn = ""
    for i in matrix.indices {
        for j in matrix.indices {
            stringToReturn.append(matrix[i][j])
        }
    }
    return stringToReturn
}

let message = cipher(column)
print(message)


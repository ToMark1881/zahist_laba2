






let surname = "вдовиченко"
let key = [5, 3, 1, 7, 4, 2, 10, 6, 8, 9]

func createDict(key: [Int], surname: String) -> [Int: Character] {
    var dict = [Int: Character]()
    let array = Array(surname)
    for index in 0..<surname.count {
        dict.updateValue(array[index], forKey: index+1)
    }
    return dict
}

let dict = createDict(key: key, surname: surname)

func cipher(surname: [Int: Character]) -> String {
    var newName = ""
    for index in 0..<surname.count  {
        
        let char = dict[key[index]] ?? Character(" ")
        newName.append(char)
        
    }
    
    return newName
}

let newSurname = cipher(surname: dict)
print(newSurname)


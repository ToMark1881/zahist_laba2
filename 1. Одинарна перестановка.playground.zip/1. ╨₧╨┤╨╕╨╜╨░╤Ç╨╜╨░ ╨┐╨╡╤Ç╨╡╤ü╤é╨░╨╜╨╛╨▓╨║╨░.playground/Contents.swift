let surname = "вдовиченко"

func cipher(surname: String) -> String {
    var newName = ""
    let workingArray = Array(surname).shuffled()
    
    for char in workingArray {
        newName.append(char)
    }
    
    return newName
}

let newSurname = cipher(surname: surname)
print(newSurname)

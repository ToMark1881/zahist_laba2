let surname = "вдовиченко"

let blockSize = 3

func addLettersToSurname(_ surname: String) -> String {
    var name = surname
    
    while name.count % blockSize != 0 {
        name.append(Character("ь"))
    }
    
    return name
}

let workingSurname = addLettersToSurname(surname)


func shuffleBlocksFromSurname(_ surname: String) -> String {
    var name = ""
    var blocks = [String]()
    var workingString = ""
    var workingIndex = 0
    for letter in surname {
        workingString.append(letter)
        if workingIndex == 2 {
            blocks.append(workingString)
            workingString.removeAll()
            workingIndex = 0
        } else {
            workingIndex += 1
        }
    }
    blocks.shuffle()
    for block in blocks {
        name.append(block)
    }
    return name
}

let newName = shuffleBlocksFromSurname(workingSurname)
print(newName)

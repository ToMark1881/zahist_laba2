let surname = "вдовиченко"
let key = [2, 3, 4, 1]
let blockSize = 3

func addLettersToSurname(_ surname: String) -> String {
    var name = surname
    
    while name.count % blockSize != 0 {
        name.append(Character("ь"))
    }
    
    return name
}

let workingSurname = addLettersToSurname(surname)


func shuffleBlocksFromSurname(_ surname: String) -> String {
    var name = ""
    var blocks = [Int: String]()
    var workingString = ""
    var workingIndex = 0
    var dictIndex = 1
    let array = Array(surname)
    for index in 0...surname.count-1 {
        workingString.append(array[index])
        if workingIndex == 2 {
            blocks.updateValue(workingString, forKey: dictIndex)
            workingString.removeAll()
            workingIndex = 0
            dictIndex += 1
        } else {
            workingIndex += 1
        }
    }
    print(blocks)
    for index in 0...blocks.count-1 {
        let str = blocks[key[index]] ?? " "
        name.append(str)
    }
    return name
}

let newName = shuffleBlocksFromSurname(workingSurname)
print(newName)
